/**
 *
 * Descripcion: Implementation of sorting functions
 *
 * Fichero: sorting.c
 * Autor: Carlos Aguirre
 * Version: 1.0
 * Fecha: 16-09-2019
 *
 */

#include "sorting.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/***************************************************/
/* Function: InsertSort Date:  12/10/25            */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Sorts an array using the insertion sort method  */
/*                                                 */
/* Input:                                          */
/* int* array: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* Output:                                         */
/* int:number of OB executions or ERR              */
/* in case of error                                */
/***************************************************/
int InsertSort(int *array, int ip, int iu)
{
  int i, j, key;
  int num = 0;

  if (!array || ip > iu)
    return ERR;

  for (i = ip + 1; i <= iu; i++)
  {
    key = array[i];
    j = i - 1;

    while (j >= ip)
    {
      num++;
      if (array[j] > key)
      {
        array[j + 1] = array[j];
        j--;
      }
      else
        break;
    }
    array[j + 1] = key;
  }

  return num;
}

/***************************************************/
/* Function: BubbleSort Date: 12/10/25             */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Sorts an array using the bubble sort method     */
/*                                                 */
/* Input:                                          */
/* int* array: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* Output:                                         */
/* int: number of swaps or ERR in case of error    */
/***************************************************/
int BubbleSort(int *array, int ip, int iu)
{
  int flag, num = 0, i, j;

  if (!array || ip > iu)
    return ERR;

  for (i = ip; i < iu - 1; i++)
  {
    flag = 0;
    for (j = ip; j < iu - i - 1; j++)
    {
      num++;
      if (array[j] > array[j + 1])
      {
        swap_(array + j, array + j + 1);

        flag = 1;
      }
    }
    if (flag == 0)
      return num;
  }

  return num;
}

/***************************************************/
/* Function: swap_ Date: 12/10/25                  */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Swaps the values of two integers                */
/*                                                 */
/* Input:                                          */
/* int *orig: pointer to first integer             */
/* int *dest: pointer to second integer            */
/* Output:                                         */
/* None                                            */
/***************************************************/
void swap_(int *orig, int *dest)
{
  int aux = *orig;
  *orig = *dest;
  *dest = aux;
}

/***************************************************/
/* Function: mergesort Date: 5/11/25               */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Sorts an array using the merge sort method      */
/*                                                 */
/* Input:                                          */
/* int* tabla: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* Output:                                         */
/* int: number of OB executions or ERR             */
/* in case of error                                */
/***************************************************/
int mergesort(int *tabla, int ip, int iu) {
  int imedio = (ip + iu) / 2, num = 0, aux = 0;
  if (!tabla) {
    return ERR;
  }

  if(ip >= iu) {
    return 0;
  }
  aux = mergesort(tabla, ip, imedio);
  if(aux == ERR) return ERR;
  num += aux;
  aux = mergesort(tabla, imedio + 1, iu);
  if(aux == ERR) return ERR;
  num += aux;
  aux = merge(tabla, ip, iu, imedio);
  if(aux == ERR) return ERR;
  num += aux;
  
  return num;
}

/***************************************************/
/* Function: merge Date: 5/11/25                   */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Sorts an array using the merge sort method      */
/*                                                 */
/* Input:                                          */
/* int* tabla: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* int imedio: medium position                     */
/* Output:                                         */
/* int: number of OB executions or ERR             */
/* in case of error                                */
/***************************************************/
int merge(int* tabla, int ip, int iu, int imedio) {
  int *tabaux = NULL, i = ip, j = imedio + 1, k = 0, num = 0;

  tabaux = (int *)malloc((iu - ip + 1) * sizeof(int));
  if (!tabaux)
  {
    return ERR;
  }

  while (i <= imedio && j <= iu)
  {
    if (tabla[i] < tabla[j])
    {
      tabaux[k] = tabla[i];
      i++;
    }
    else
    {
      tabaux[k] = tabla[j];
      j++;
    }
    k++;
    num++;
  }

  if (i > imedio)
  {
    while (j <= iu)
    {
      tabaux[k] = tabla[j];
      j++, k++;
    }
  }
  else if (j > iu)
  {
    while (i <= imedio)
    {
      tabaux[k] = tabla[i];
      i++, k++;
    }
  }

  for (i = 0; i < (iu - ip + 1); i++)
    tabla[ip + i] = tabaux[i];

  free(tabaux);
  return num;
}
/***************************************************/
/* Function: quicksort Date: 5/11/25               */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Sorts an array using the quick sort method      */
/*                                                 */
/* Input:                                          */
/* int* tabla: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* Output:                                         */
/* int: number of OB executions or ERR             */
/* in case of error                                */
/***************************************************/
int quicksort(int *tabla, int ip, int iu) {
  int M = 0, ob = 0, aux = 0;
  if(ip > iu) {
    return 0;
  }

  if(ip == iu) {
    return 0;
  } else {
      aux = partition(tabla, ip, iu, &M);
      if(aux == ERR) return ERR;
      ob += aux;
      if (ip < M - 1) {
        aux = quicksort(tabla, ip, M - 1);
        if(aux == ERR) return ERR;
        ob += aux;    
      }
        if(M + 1 < iu) {
        aux = quicksort(tabla, M + 1, iu);
        if(aux == ERR) return ERR;
        ob += aux;
    }
  }

  return ob;
}
/***************************************************/
/* Function: partition Date: 5/11/25               */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Sorts an array using the partitions             */
/*                                                 */
/* Input:                                          */
/* int* tabla: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* int pos: position of the pivot                  */
/* Output:                                         */
/* int: number of OB executions or ERR             */
/* in case of error                                */
/***************************************************/
int partition(int* tabla, int ip, int iu,int *pos) {
  int pivot = 0, i = 0, ob = 0;
  ob = median(tabla, ip, iu, pos);
  /*ob = median_avg(tabla, ip, iu, pos);*/
  /*ob = median_stat(tabla, ip, iu, pos);*/
  
  pivot = tabla[*pos];
  swap_(tabla + ip, tabla + (*pos));
  *pos = ip;
  for(i = ip + 1; i <= iu; i++) {
    ob++;
    if(tabla[i]< pivot) {
      (*pos)++;
      swap_(tabla + i, tabla + (*pos));
    }
  }
  swap_(tabla+ip, tabla+(*pos));
  return ob;


}
/***************************************************/
/* Function: median    Date: 5/11/25               */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Select the first position as the pivot position */
/*                                                 */
/* Input:                                          */
/* int* tabla: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* int pos: position of the pivot                  */
/* Output:                                         */
/* int 0                                           */
/***************************************************/
int median(int *tabla,int ip, int iu,int *pos){
  *pos = ip;
  return 0;
}
/***************************************************/
/* Function: median    Date: 5/11/25               */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Select the medium position as the pivot position*/
/*                                                 */
/* Input:                                          */
/* int* tabla: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* int pos: position of the pivot                  */
/* Output:                                         */
/* int 0                                           */
/***************************************************/
int median_avg(int *tabla, int ip, int iu, int *pos) {
  *pos = (ip + iu) /2;
  return 0;
}
/***************************************************/
/* Function: median_stat  Date: 5/11/25            */
/* Authors: Pablo Plaza y Ernest Çelo              */
/*                                                 */
/* Select the first, medium or last position       */
/* as the pivot position                           */
/*                                                 */
/* Input:                                          */
/* int* tabla: array to sort                       */
/* int ip: initial position                        */
/* int iu: final position                          */
/* int pos: position of the pivot                  */
/* Output:                                         */
/* int 0                                           */
/***************************************************/
int median_stat(int *tabla, int ip, int iu, int *pos) {
int med = (ip + iu) / 2;
  
  if (tabla[ip] < tabla[med]) {
      if (tabla[med] < tabla[iu]) {
          *pos = med;
          return 2;
      } else {
          if (tabla[ip] < tabla[iu]) {
              *pos = iu;
          } else {
              *pos = ip;
          }
          return 3;
      }
        
  } else {
      if (tabla[med] > tabla[iu]) {
          *pos = med;
          return 2;
      } else {
          if (tabla[ip] < tabla[iu]) {
              *pos = ip;
          } else {
              *pos = iu;
          }
          return 3;
      }
  }
}
